# trading-strategies-backend
Trading strategies backend

## Pre-requisites
- NodeJS (https://nodejs.org/en/download/)
- MongoDB (https://www.mongodb.com/docs/atlas/getting-started/)


## Installation
```
npm install
```

## Configuration Setup
Rename *.env.local* to *.env* and update MONGODB_URL with mongodb instance created using MongoDB Atlas.

## Running application
```
npm run start
```
## APIs
Click http://localhost:3000/api to view developed APIs.
