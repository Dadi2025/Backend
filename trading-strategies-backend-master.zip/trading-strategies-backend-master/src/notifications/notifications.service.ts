import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateNotificationDto } from './dto/create-notification.dto';
import {
  Notification,
  NotificationDocument,
} from './schemas/notification.schema';

function getHash(str, algo = 'SHA-256') {
  let strBuf = new TextEncoder().encode(str);
  return crypto.subtle.digest(algo, strBuf).then((hash) => {
    let result = '';
    const view = new DataView(hash);
    for (let i = 0; i < hash.byteLength; i += 4) {
      result += ('00000000' + view.getUint32(i).toString(16)).slice(-8);
    }
    return result;
  });
}

@Injectable()
export class NotificationsService {
  constructor(
    @InjectModel(Notification.name)
    private readonly ruleModel: Model<NotificationDocument>,
  ) {}

  async create(
    createNotificationDto: CreateNotificationDto,
  ): Promise<Notification> {
    const createNotification = new this.ruleModel(createNotificationDto);
    createNotification._id = await getHash(createNotification.message);
    const rule = await this.findOneById(createNotification._id);
    if (rule) {
      throw new BadRequestException();
    }
    createNotification.createdAt = new Date();
    return createNotification.save();
  }

  async findOne(name: string): Promise<Notification | undefined> {
    return this.ruleModel
      .findOne({
        name,
      })
      .exec();
  }

  async findOneById(id: string): Promise<Notification | undefined> {
    return this.ruleModel
      .findOne({
        _id: id,
      })
      .exec();
  }

  async findAll(): Promise<Notification[] | undefined> {
    const filters = [];
    return this.ruleModel.find({}).exec();
  }
}
