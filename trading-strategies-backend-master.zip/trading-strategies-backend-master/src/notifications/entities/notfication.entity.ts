export class Notification {
  _id: string;
  message: string;
  ruleId: string;
  createdAt: Date;
}