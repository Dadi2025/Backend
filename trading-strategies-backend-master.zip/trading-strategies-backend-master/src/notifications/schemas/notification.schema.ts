import { Schema, SchemaFactory, Prop } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type NotificationDocument = HydratedDocument<Notification>;

@Schema()
export class Notification {
  @Prop({
    required: true,
  })
  _id: string;
  @Prop({
    required: true,
  })
  message: string;
  @Prop({
    required: true,
  })
  ruleId: string;
  @Prop({
    required: true,
  })
  createdAt: Date;
}

export const NotificationSchema = SchemaFactory.createForClass(Notification);
