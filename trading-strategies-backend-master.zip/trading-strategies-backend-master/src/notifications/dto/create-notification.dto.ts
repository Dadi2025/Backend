import { Notification } from '../entities/notfication.entity';

export class CreateNotificationDto extends Notification {}
