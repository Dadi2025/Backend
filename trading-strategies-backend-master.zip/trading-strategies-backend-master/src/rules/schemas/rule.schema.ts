import { Schema, SchemaFactory, Prop } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type RuleDocument = HydratedDocument<Rule>;

@Schema()
export class Rule {
  @Prop({
    required: true,
  })
  _id: string;
  @Prop({
    required: true,
  })
  name: string;
  @Prop({
    required: true,
  })
  jsonLogic: string;
  @Prop({
    required: true
  })
  createdAt: Date;
}

export const RuleSchema = SchemaFactory.createForClass(Rule);
