export class Rule {
  _id: string;
  name: string;
  jsonLogic: string;
  createdAt: Date;
}