import { Rule } from '../entities/rule.entity';

export class CreateRuleDto extends Rule {}
