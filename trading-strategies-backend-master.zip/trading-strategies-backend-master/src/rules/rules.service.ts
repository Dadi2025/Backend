import { Injectable, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CreateRuleDto } from './dto/create-rule.dto';
import { Rule, RuleDocument } from './schemas/rule.schema';

function getHash(str, algo = 'SHA-256') {
  let strBuf = new TextEncoder().encode(str);
  return crypto.subtle.digest(algo, strBuf).then((hash) => {
    let result = '';
    const view = new DataView(hash);
    for (let i = 0; i < hash.byteLength; i += 4) {
      result += ('00000000' + view.getUint32(i).toString(16)).slice(-8);
    }
    return result;
  });
}

@Injectable()
export class RulesService {
  constructor(
    @InjectModel(Rule.name) private readonly ruleModel: Model<RuleDocument>,
  ) {}

  async create(createRuleDto: CreateRuleDto): Promise<Rule> {
    const createRule = new this.ruleModel(createRuleDto);
    createRule._id = await getHash(createRule.jsonLogic);
    const rule = await this.findOneById(createRule._id);
    if (rule) {
      throw new BadRequestException();
    }
    createRule.createdAt = new Date();
    return createRule.save();
  }

  async findOne(name: string): Promise<Rule | undefined> {
    return this.ruleModel
      .findOne({
        name,
      })
      .exec();
  }

  async findOneById(id: string): Promise<Rule | undefined> {
    return this.ruleModel
      .findOne({
        _id: id,
      })
      .exec();
  }

  async findAll(): Promise<Rule[] | undefined> {
    const filters = [];
    return this.ruleModel.find({}).exec();
  }
}
